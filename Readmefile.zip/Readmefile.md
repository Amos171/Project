﻿**Aim:**Alcohol Detection System **Result:** 



|**Test Scenario**|**Observed Analog Value**|**Digital Value**|**LED**|**Buzzer**|
| - | - | - | - | - |
|No alcohol near sensor|Low (e.g., 100–200)|HIGH (1)|OFF|OFF|
|Alcohol vapors introduced|High (e.g., 400–600)|LOW (0)|ON|ON|

• When the driver breathes out alcohol vapors and concentration 

exceeds preset level:

- LED lights up
- Buzzer sounds an alert
- Analog value on Serial Monitor increases
- Digital value changes from HIGH (1) to LOW (0)
- When no alcohol is present:
  - LED and buzzer remain OFF
  - Digital value remains HIGH (1)

Footer 1
